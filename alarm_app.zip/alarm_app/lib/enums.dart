enum MenuType {
  clock,
  alarm,
  timer,
  stopwatch
}